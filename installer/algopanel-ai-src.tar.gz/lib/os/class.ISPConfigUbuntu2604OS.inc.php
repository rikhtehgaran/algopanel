<?php
/**
 * Description of class
 *
 * @author croydon
 */
class ISPConfigUbuntu2604OS extends ISPConfigUbuntu2404OS {

	protected function configureApt() {
		// enable contrib and non-free
		ISPConfigLog::info('Configuring apt repositories.', true);

		if($this->getOSArchitecture() == 'arm64') {
			$contents = '# updated by ISPConfig auto installer
Types: deb
URIs: http://ports.ubuntu.com/ubuntu-ports/
Suites: resolute resolute-updates resolute-backports
Components: main restricted universe multiverse
Signed-By: /usr/share/keyrings/ubuntu-archive-keyring.gpg

Types: deb
URIs: http://ports.ubuntu.com/ubuntu-ports/
Suites: resolute-security
Components: main restricted universe multiverse
Signed-By: /usr/share/keyrings/ubuntu-archive-keyring.gpg
';
		 } else {
			$contents = '# updated by ISPConfig auto installer
Types: deb
URIs: http://archive.ubuntu.com/ubuntu/
Suites: resolute resolute-updates resolute-backports
Components: main restricted universe multiverse
Signed-By: /usr/share/keyrings/ubuntu-archive-keyring.gpg

Types: deb
URIs: http://security.ubuntu.com/ubuntu/
Suites: resolute-security
Components: main restricted universe multiverse
Signed-By: /usr/share/keyrings/ubuntu-archive-keyring.gpg
';
		 }
		file_put_contents('/etc/apt/sources.list.d/ubuntu.sources', $contents);
	}

	// TODO: Remove this override once a stable ISPConfig release supports Ubuntu 26.04
	protected function isStableSupported() {
		return false;
	}

	protected function getInitialPackages() {
		$packages = parent::getInitialPackages();

		// ntp is replaced by ntpsec in Ubuntu 26.04
		$key = array_search('ntp', $packages, true);
		if($key !== false) {
			unset($packages[$key]);
			$packages[] = 'ntpsec';
		}

		return $packages;
	}

	protected function getPackagesToInstall($section) {
		$packages = parent::getPackagesToInstall($section);

		if($section === 'stats') {
			// webalizer is no longer available in Ubuntu 26.04
			$key = array_search('webalizer', $packages, true);
			if($key !== false) {
				unset($packages[$key]);
			}
		}

		return $packages;
	}

	protected function setDefaultPHP() {
		ISPConfigLog::info('Setting default system PHP version.', true);
		$cmd = 'update-alternatives --set php /usr/bin/php' . $this->getSystemPHPVersion();
		$result = $this->exec($cmd);
		if($result === false) {
			throw new ISPConfigOSException('Command ' . $cmd . ' failed.');
		}

		if(ISPConfig::shallInstall('web')) {
			$cmd = 'update-alternatives --set php-cgi /usr/bin/php-cgi' . $this->getSystemPHPVersion() . ' ; update-alternatives --set php-cgi-bin /usr/lib/cgi-bin/php' . $this->getSystemPHPVersion();
			$result = $this->exec($cmd);
			if($result === false) {
				throw new ISPConfigOSException('Command ' . $cmd . ' failed.');
			}
			// php-fpm.sock alternative is only registered by sury multi-PHP packages.
			// On Ubuntu 26.04, it may not exist if sury packages don't provide it yet.
			$cmd = 'update-alternatives --set php-fpm.sock /run/php/php' . $this->getSystemPHPVersion() . '-fpm.sock 2>/dev/null';
			$this->exec($cmd, array(2));
		}
	}

	protected function addSuryRepo() {
		ISPConfigLog::info('Activating sury php repository.', true);

		// The legacy PPA (ppa:ondrej/php) is no longer available for Ubuntu 26.04.
		// Use the unified packages.sury.org repository instead.
		$cmd = 'curl -sSLo /tmp/debsuryorg-archive-keyring.deb https://packages.sury.org/debsuryorg-archive-keyring.deb'
			. ' && dpkg -i /tmp/debsuryorg-archive-keyring.deb'
			. ' && echo "deb [signed-by=/usr/share/keyrings/debsuryorg-archive-keyring.gpg] https://packages.sury.org/php/ $(lsb_release -sc) main" > /etc/apt/sources.list.d/php-sury.list';
		$result = $this->exec($cmd);
		if($result === false) {
			throw new ISPConfigOSException('Command ' . $cmd . ' failed.');
		}
	}

	protected function addRspamdRepo() {
		// Rspamd is available in Ubuntu 26.04 official repositories, no external repo needed
		ISPConfigLog::info('Using Rspamd from Ubuntu repositories.', true);
	}

	protected function addGoAccessRepo() {
		// GoAccess is available in Ubuntu 26.04 official repositories, no external repo needed
		ISPConfigLog::info('Using GoAccess from Ubuntu repositories.', true);
	}

	protected function getSystemPHPVersion() {
		return '8.5';
	}

}
