<?php

require __DIR__ . '/class.ISPConfigDebian12OS.inc.php';

/**
 * Debian 13 (Trixie) specific installer class
 *
 * @author croydon
 */
class ISPConfigDebian13OS extends ISPConfigDebian12OS {

	protected function getSystemPHPVersion() {
		return '8.4';
	}

	protected function configureApt() {
		// Debian 13 uses deb822 format in /etc/apt/sources.list.d/debian.sources
		$deb822_file = '/etc/apt/sources.list.d/debian.sources';

		if(file_exists($deb822_file)) {
			ISPConfigLog::info('Enabling contrib and non-free repositories (deb822 format).', true);
			$content = file_get_contents($deb822_file);

			// Add contrib to Components line if not present
			if(strpos($content, 'contrib') === false) {
				$content = preg_replace(
					'/^(Components:\s*.*?)$/m',
					'$1 contrib',
					$content
				);
			}

			// Add non-free to Components line if not present (check for standalone non-free, not just non-free-firmware)
			if(preg_match('/\bnon-free\b(?!-firmware)/', $content) === 0) {
				$content = preg_replace(
					'/^(Components:\s*.*?)$/m',
					'$1 non-free',
					$content
				);
			}

			file_put_contents($deb822_file, $content);
		} else {
			// Fallback to traditional sources.list format
			parent::configureApt();
		}
	}

	protected function getInitialPackages() {
		$packages = parent::getInitialPackages();

		// software-properties-common is not available in Debian 13
		$key = array_search('software-properties-common', $packages, true);
		if($key !== false) {
			unset($packages[$key]);
		}

		// ntp is replaced by ntpsec in Debian 13
		$key = array_search('ntp', $packages, true);
		if($key !== false) {
			unset($packages[$key]);
			$packages[] = 'ntpsec';
		}

		return $packages;
	}

	protected function getPackagesToInstall($section) {
		$packages = parent::getPackagesToInstall($section);

		// software-properties-common is not available in Debian 13
		$key = array_search('software-properties-common', $packages, true);
		if($key !== false) {
			unset($packages[$key]);
		}

		return $packages;
	}

	protected function getWebserverPackages() {
		$packages = parent::getWebserverPackages();

		// libapache2-mod-python is not available in Debian 13
		$key = array_search('libapache2-mod-python', $packages, true);
		if($key !== false) {
			unset($packages[$key]);
		}

		return $packages;
	}

	protected function addGoAccessRepo() {
		// GoAccess is available in Debian 13 official repositories, no external repo needed
		ISPConfigLog::info('Using GoAccess from Debian repositories.', true);
	}

	protected function installMailman($host_name) {
		ISPConfigLog::info('ISPConfig does not yet support mailman3 and mailman2 is no longer available in Debian 13.', true);
		return;
	}

	public function runPerfectSetup() {
		// Debian 13 lacks php8.4-imap in system repos, so we must use sury repo
		// Replace 'system' with '8.4' in use-php option, avoiding duplicates
		$this->fixSystemPHPOption();

		return parent::runPerfectSetup();
	}

	/**
	 * Fix PHP option where 'system' must be replaced with '8.4'
	 * because Debian 13 lacks php8.4-imap in system repos (sury repo has it)
	 */
	private function fixSystemPHPOption() {
		if(!isset($_GET['use-php']) || !$_GET['use-php']) {
			return;
		}

		$use_php = $_GET['use-php'];

		// Handle pure 'system' case
		if($use_php === 'system') {
			$_GET['use-php'] = '8.4';
			ISPConfigLog::info('Debian 13: Changed --use-php=system to --use-php=8.4 (php8.4-imap not available in system repos)', true);
			return;
		}

		// Handle comma-separated list containing 'system'
		$versions = explode(',', $use_php);
		$has_system = in_array('system', $versions, true);

		if($has_system) {
			// Remove 'system' from the list
			$versions = array_filter($versions, function($v) {
				return $v !== 'system';
			});

			// Add '8.4' if not already present
			if(!in_array('8.4', $versions, true)) {
				$versions[] = '8.4';
			}

			$_GET['use-php'] = implode(',', $versions);
			ISPConfigLog::info('Debian 13: Replaced "system" with "8.4" in --use-php option (php8.4-imap not available in system repos)', true);
		}
	}

}
